
#CyberJS
   ____      _                  _____ _  __
 / ___|   _| |__   ___ _ __   |_   _| |/ /
| |  | | | | '_ \ / _ \ '__|____| | | ' /
| |__| |_| | |_) |  __/ | |_____| | | . \
 \____\__, |_.__/ \___|_|       |_| |_|\_\
      |___/
 -    Continue To Follow Cyber-TK
-    Node -V 8.4.0
-    Node Version update 
-    npm i -g npm
#
-    ║(O)║♫ ♪ ♫ ♪
-╚══╝
-▄ █ ▄ █ ▄ ▄ █ ▄ █ ▄ █
-Min- - - - - - - - - - - -●Max 
#
#    Bot İs Running
-    http://github.com/CyberTKR/CyberJS.git
-    cd CyberJS & npm install
-    npm start

# Account
-    Line Contact ;
-    cybertk0)
-    Url;
-    http://line.me//ti/p/~cybertk0
-    CyberTKBOT
-    Cybertk Bot scripti'dir.
-    Grup savunmasi amacli kullanilmalidir.
-    Baska herhangi bir amacla kullanilmak icin duzenlenmesinden ve, 
-    kullanilmasindan cybertk sorumlu degildir.
-    Instagram account : http://instagram.com/_aquariusman 
-    Youtube channnel : https://m.youtube.com/channel/UC9AyYKWovERexyOFy3h4rdw

 
